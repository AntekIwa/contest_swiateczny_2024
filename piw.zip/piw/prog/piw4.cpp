/*
    23.12.22024
    Rozwiązanie O(n log n) - Lukasz Grabowski
*/

///SPONSORED BY UNDEINATORV7.EXE
#include <iostream>
#include <algorithm>

using namespace std;
//Mozna wyszukac binarnie, ale mozna walnac zwyklego sorta (walne sorta, pewnie we wszytskich zadaniach jest binsearch)
constexpr int MN=1e5+5;
int tab[MN];

int main()
{
ios_base::sync_with_stdio(0); cin.tie(NULL);
int n; long long s=0,p;
cin>> n>>p;
for(int j=0;j<n;j++)  cin>> tab[j];
sort(tab,tab+n);
for(int j=0;j<n;j++)
{
    long long war=tab[j];
    if(s+war*(n-j)>=p){//wyznaczamy MATEMATYCZNIE najmniejsze war
        cout<<(p-s+n-j-1)/(n-j)<<'\n';return 0;}
    s+=war;
}
cout<<"NIE\n";

return 0;
}