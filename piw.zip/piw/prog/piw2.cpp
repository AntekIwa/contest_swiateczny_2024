/*
  22.12.2024
  Rozwiazanie O(n * max(h[i])) - Antoni Iwanowski
*/

#include <bits/stdc++.h>
#define nl endl
#define pb push_back
#define ll long long
using namespace std;
const int maxn = 1e5+5;
int n, v;
// n log n
int ans = 0;
vector <int> h;

ll sumuj(int H) {
    ll suma = 0;
    for (int i = 0; i < n; i++) suma += min(h[i], H);
    return suma;
}

    
int32_t main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    
    cin >> n >> v;
    
    for (int i = 0; i < n; i++) {
        int x; cin >> x;
        h.pb(x);
    }
    
    sort(h.begin(), h.end());
	int res = 1e9 + 7;
	for(int i = 0; i <= h.back(); i++){
		if(sumuj(i) >= v){
            res = i;
            break;
        }
	}
    if (res == 1e9 + 7) cout << "NIE" << nl;
    else cout << res << nl;
}
